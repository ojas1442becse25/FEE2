import { Link } from 'react-router-dom';
import './CartEmpty.css';

export default function CartEmpty() {
  return (
    <div className="cart-empty">
      <div className="empty-icon">🛒</div>
      <h2>Your Cart is Empty</h2>
      <p>Looks like you haven't added any items to your cart yet.</p>
      <Link to="/products" className="shop-now-btn">
        Shop Now
      </Link>
    </div>
  );
}

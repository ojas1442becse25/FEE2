import { useAppDispatch } from '../../store/hooks';
import {
  removeFromCart,
  increaseQuantity,
  decreaseQuantity,
} from '../../store/slices/cartSlice';
import { formatPrice } from '../../utils/formatters';
import './CartItem.css';

export default function CartItem({ item }) {
  const dispatch = useAppDispatch();

  const handleIncrease = () => {
    dispatch(increaseQuantity({ id: item.id }));
  };

  const handleDecrease = () => {
    dispatch(decreaseQuantity({ id: item.id }));
  };

  const handleRemove = () => {
    dispatch(removeFromCart({ id: item.id }));
  };

  const itemTotal = item.price * item.quantity;

  return (
    <div className="cart-item">
      <img src={item.image} alt={item.name} className="cart-item-image" />
      <div className="cart-item-details">
        <h4 className="cart-item-name">{item.name}</h4>
        <p className="cart-item-price">{formatPrice(item.price)} each</p>
      </div>
      <div className="cart-item-controls">
        <button className="quantity-btn" onClick={handleDecrease}>
          −
        </button>
        <input
          type="number"
          value={item.quantity}
          readOnly
          className="quantity-input"
        />
        <button className="quantity-btn" onClick={handleIncrease}>
          +
        </button>
      </div>
      <div className="cart-item-total">
        <p className="total-price">{formatPrice(itemTotal)}</p>
      </div>
      <button className="remove-btn" onClick={handleRemove}>
        ✕
      </button>
    </div>
  );
}

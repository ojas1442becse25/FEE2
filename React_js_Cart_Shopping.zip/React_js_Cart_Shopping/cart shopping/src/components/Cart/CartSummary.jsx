import { Link } from 'react-router-dom';
import { formatPrice, getTaxAmount, getTotalWithTax } from '../../utils/formatters';
import './CartSummary.css';

export default function CartSummary({ total }) {
  const taxAmount = getTaxAmount(total);
  const totalWithTax = getTotalWithTax(total);

  return (
    <div className="cart-summary">
      <h3>Order Summary</h3>
      <div className="summary-row">
        <span>Subtotal:</span>
        <span>{formatPrice(total)}</span>
      </div>
      <div className="summary-row">
        <span>Tax (10%):</span>
        <span>{formatPrice(taxAmount)}</span>
      </div>
      <div className="summary-divider"></div>
      <div className="summary-row total">
        <span>Total:</span>
        <span>{formatPrice(totalWithTax)}</span>
      </div>
      <Link to="/checkout" className="checkout-btn">
        Proceed to Checkout
      </Link>
      <Link to="/products" className="continue-shopping-btn">
        Continue Shopping
      </Link>
    </div>
  );
}

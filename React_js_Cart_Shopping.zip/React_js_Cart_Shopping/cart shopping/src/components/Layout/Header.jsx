import { Link } from 'react-router-dom';
import { useAppSelector } from '../../store/hooks';
import { selectCartCount } from '../../store/hooks';
import './Header.css';

export default function Header() {
  const cartCount = useAppSelector(selectCartCount);

  return (
    <header className="header">
      <div className="header-container">
        <Link to="/" className="logo">
          🛒 ShopHub
        </Link>
        <nav className="navbar">
          <Link to="/" className="nav-link">
            Home
          </Link>
          <Link to="/products" className="nav-link">
            Products
          </Link>
          <Link to="/about" className="nav-link">
            About
          </Link>
          <Link to="/cart" className="nav-link cart-link">
            Cart
            {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
          </Link>
        </nav>
      </div>
    </header>
  );
}

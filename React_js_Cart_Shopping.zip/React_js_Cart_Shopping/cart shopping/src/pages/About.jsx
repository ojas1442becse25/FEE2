import { Link } from 'react-router-dom';
import './About.css';

export default function About() {
  return (
    <div className="about-page">
      <div className="about-container">
        <h1>About ShopHub</h1>

        <section className="about-section">
          <h2>Who We Are</h2>
          <p>
            ShopHub is a leading online retailer specializing in quality tech products
            and accessories. Founded in 2020, we've been committed to providing our
            customers with the best selection of products at competitive prices.
          </p>
        </section>

        <section className="about-section">
          <h2>Our Mission</h2>
          <p>
            Our mission is to make shopping for tech products easy, affordable, and
            enjoyable. We believe in quality, customer service, and innovation. Every
            product in our catalog is carefully selected to meet our high standards.
          </p>
        </section>

        <section className="about-section">
          <h2>Why Choose Us?</h2>
          <ul className="about-list">
            <li>✓ Wide selection of quality products</li>
            <li>✓ Competitive pricing and regular deals</li>
            <li>✓ Fast and reliable shipping</li>
            <li>✓ 30-day return policy</li>
            <li>✓ Excellent customer support</li>
            <li>✓ Secure payment processing</li>
          </ul>
        </section>

        <section className="about-section">
          <h2>Our Commitment</h2>
          <p>
            We are committed to providing you with an exceptional shopping experience.
            If you have any questions or concerns, please don't hesitate to contact us.
            Your satisfaction is our priority.
          </p>
        </section>

        <section className="about-section contact-section">
          <h2>Get in Touch</h2>
          <div className="contact-info">
            <p><strong>Email:</strong> info@shophub.com</p>
            <p><strong>Phone:</strong> +1 (555) 123-4567</p>
            <p><strong>Hours:</strong> Monday - Friday, 9 AM - 6 PM EST</p>
          </div>
        </section>

        <div className="back-link">
          <Link to="/">← Back to Home</Link>
        </div>
      </div>
    </div>
  );
}

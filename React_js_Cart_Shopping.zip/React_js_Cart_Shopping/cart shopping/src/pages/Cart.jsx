import { useAppSelector, selectCartItems, selectCartTotal } from '../store/hooks';
import CartItem from '../components/Cart/CartItem';
import CartEmpty from '../components/Cart/CartEmpty';
import CartSummary from '../components/Cart/CartSummary';
import './Cart.css';

export default function Cart() {
  const cartItems = useAppSelector(selectCartItems);
  const cartTotal = useAppSelector(selectCartTotal);

  if (cartItems.length === 0) {
    return (
      <div className="cart-page">
        <h1>Shopping Cart</h1>
        <CartEmpty />
      </div>
    );
  }

  return (
    <div className="cart-page">
      <h1>Shopping Cart</h1>
      <div className="cart-container">
        <div className="cart-items-section">
          <div className="items-header">
            <span>{cartItems.length} item(s) in cart</span>
          </div>
          {cartItems.map((item) => (
            <CartItem key={item.id} item={item} />
          ))}
        </div>
        <CartSummary total={cartTotal} />
      </div>
    </div>
  );
}

import { Link } from 'react-router-dom';
import ProductGrid from '../components/Product/ProductGrid';
import { getProducts } from '../services/api';
import './Home.css';

export default function Home() {
  const featuredProducts = getProducts().slice(0, 4);

  return (
    <div className="home">
      <section className="hero">
        <div className="hero-content">
          <h1>Welcome to ShopHub</h1>
          <p>Your one-stop shop for quality tech products and accessories</p>
          <div className="hero-buttons">
            <Link to="/products" className="btn btn-primary">
              Browse Products
            </Link>
            <Link to="/about" className="btn btn-secondary">
              Learn More
            </Link>
          </div>
        </div>
      </section>

      <section className="featured-section">
        <div className="container">
          <h2>Featured Products</h2>
          <ProductGrid products={featuredProducts} />
          <div className="view-all">
            <Link to="/products" className="view-all-btn">
              View All Products →
            </Link>
          </div>
        </div>
      </section>

      <section className="benefits">
        <div className="container">
          <h2>Why Shop With Us?</h2>
          <div className="benefits-grid">
            <div className="benefit-item">
              <div className="benefit-icon">🚚</div>
              <h3>Fast Delivery</h3>
              <p>Get your products delivered quickly and safely</p>
            </div>
            <div className="benefit-item">
              <div className="benefit-icon">💳</div>
              <h3>Secure Payment</h3>
              <p>Your payment information is always protected</p>
            </div>
            <div className="benefit-item">
              <div className="benefit-icon">↩️</div>
              <h3>Easy Returns</h3>
              <p>30-day return policy for peace of mind</p>
            </div>
            <div className="benefit-item">
              <div className="benefit-icon">⭐</div>
              <h3>Quality Products</h3>
              <p>Hand-picked selection of top brands</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

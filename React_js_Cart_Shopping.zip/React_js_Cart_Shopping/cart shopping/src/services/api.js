// Mock product data - Prices in Indian Rupees (INR)
export const products = [
  {
    id: 1,
    name: 'Wireless Headphones',
    price: 6639,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
    category: 'Electronics',
    description: 'High-quality wireless headphones with noise cancellation',
  },
  {
    id: 2,
    name: 'Smart Watch',
    price: 16599,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    category: 'Electronics',
    description: 'Feature-rich smartwatch with fitness tracking',
  },
  {
    id: 3,
    name: 'Laptop Backpack',
    price: 4149,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop',
    category: 'Accessories',
    description: 'Durable laptop backpack with multiple compartments',
  },
  {
    id: 4,
    name: 'USB-C Cable',
    price: 1079,
    image: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400&h=400&fit=crop',
    category: 'Accessories',
    description: 'Fast charging USB-C cable, 2 meters long',
  },
  {
    id: 5,
    name: 'Portable SSD',
    price: 10789,
    image: 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=400&h=400&fit=crop',
    category: 'Storage',
    description: '1TB portable solid state drive with USB 3.1',
  },
  {
    id: 6,
    name: 'Mechanical Keyboard',
    price: 7469,
    image: 'https://images.unsplash.com/photo-1587829191301-dc798b83add3?w=400&h=400&fit=crop',
    category: 'Accessories',
    description: 'RGB mechanical keyboard with custom switches',
  },
  {
    id: 7,
    name: 'Webcam 1080p',
    price: 4979,
    image: 'https://images.unsplash.com/photo-1598986646514-f3e9fda4d38e?w=400&h=400&fit=crop',
    category: 'Electronics',
    description: 'Full HD webcam with auto-focus and built-in mic',
  },
  {
    id: 8,
    name: 'Phone Stand',
    price: 1659,
    image: 'https://images.unsplash.com/photo-1605559424843-9e4c3ca4628d?w=400&h=400&fit=crop',
    category: 'Accessories',
    description: 'Adjustable phone stand for desk or bed',
  },
  {
    id: 9,
    name: 'Portable Charger',
    price: 3319,
    image: 'https://images.unsplash.com/photo-1609042231298-612664891435?w=400&h=400&fit=crop',
    category: 'Accessories',
    description: '20000mAh portable charger with fast charging',
  },
  {
    id: 10,
    name: 'Bluetooth Speaker',
    price: 4979,
    image: 'https://images.unsplash.com/photo-1589003077984-894e133da579?w=400&h=400&fit=crop',
    category: 'Electronics',
    description: 'Waterproof portable Bluetooth speaker',
  },
];

export const getProducts = () => products;

export const getProductById = (id) => products.find((p) => p.id === id);

export const searchProducts = (query) => {
  const lowerQuery = query.toLowerCase();
  return products.filter(
    (p) =>
      p.name.toLowerCase().includes(lowerQuery) ||
      p.description.toLowerCase().includes(lowerQuery)
  );
};

export const filterProductsByCategory = (category) => {
  if (!category) return products;
  return products.filter((p) => p.category === category);
};

export const getCategories = () => {
  const categories = new Set(products.map((p) => p.category));
  return Array.from(categories);
};

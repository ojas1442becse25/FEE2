const CART_KEY = 'cart_items';

export const saveCartToLocalStorage = (cartItems) => {
  try {
    localStorage.setItem(CART_KEY, JSON.stringify(cartItems));
  } catch (error) {
    console.error('Failed to save cart to localStorage:', error);
  }
};

export const getCartFromLocalStorage = () => {
  try {
    const items = localStorage.getItem(CART_KEY);
    return items ? JSON.parse(items) : [];
  } catch (error) {
    console.error('Failed to get cart from localStorage:', error);
    return [];
  }
};

export const clearCartFromLocalStorage = () => {
  try {
    localStorage.removeItem(CART_KEY);
  } catch (error) {
    console.error('Failed to clear cart from localStorage:', error);
  }
};

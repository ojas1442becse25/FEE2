export const formatPrice = (price) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
  }).format(price);
};

export const getTaxAmount = (total) => {
  return total * 0.1; // 10% tax
};

export const getTotalWithTax = (total) => {
  return total + getTaxAmount(total);
};
